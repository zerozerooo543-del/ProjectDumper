-keep class com.il2cpp.runtimedumper.NativeDumper { *; }
-keepclassmembers class com.il2cpp.runtimedumper.NativeDumper {
    public static *;
}
