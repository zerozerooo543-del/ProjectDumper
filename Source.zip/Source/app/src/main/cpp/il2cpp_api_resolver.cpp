#include "il2cpp_api_resolver.h"
#include "mem_reader.h"
#include "crash_handler.h"
#include <dlfcn.h>
#include <cstring>
#include <android/log.h>

#define LOG_TAG "Il2CppDumper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ApiResolver {

template<typename T>
static bool loadSym(void* handle, const char* name, T& out) {
    void* sym = dlsym(handle, name);
    if (!sym) {
        LOGW("dlsym failed for %s: %s", name, dlerror());
        out = nullptr;
        return false;
    }
    out = reinterpret_cast<T>(sym);
    return true;
}

bool resolve(const std::string& libName, Il2CppApi& api) {
    memset(&api, 0, sizeof(api));

    // RTLD_NOLOAD — library must already be mapped by the game
    void* handle = dlopen(libName.c_str(), RTLD_NOW | RTLD_NOLOAD);
    if (!handle) {
        // try with full path variants or just the basename again
        handle = dlopen(libName.c_str(), RTLD_NOW);
    }
    if (!handle) {
        LOGE("dlopen(%s) failed: %s", libName.c_str(), dlerror());
        return false;
    }
    api.handle = handle;

    uintptr_t base = 0, end = 0;
    std::string path;
    if (MemReader::findLibrary(libName, base, end, path)) {
        api.base = base;
        LOGI("Library base = 0x%zx path = %s", (size_t)base, path.c_str());
    }

    bool ok = true;

    // Critical APIs
    ok &= loadSym(handle, "il2cpp_domain_get", api.domain_get);
    ok &= loadSym(handle, "il2cpp_domain_get_assemblies", api.domain_get_assemblies);
    ok &= loadSym(handle, "il2cpp_assembly_get_image", api.assembly_get_image);

    ok &= loadSym(handle, "il2cpp_image_get_name", api.image_get_name);
    ok &= loadSym(handle, "il2cpp_image_get_class_count", api.image_get_class_count);
    ok &= loadSym(handle, "il2cpp_image_get_class", api.image_get_class);

    ok &= loadSym(handle, "il2cpp_class_get_name", api.class_get_name);
    ok &= loadSym(handle, "il2cpp_class_get_namespace", api.class_get_namespace);
    ok &= loadSym(handle, "il2cpp_class_get_parent", api.class_get_parent);
    ok &= loadSym(handle, "il2cpp_class_is_enum", api.class_is_enum);
    ok &= loadSym(handle, "il2cpp_class_is_interface", api.class_is_interface);
    ok &= loadSym(handle, "il2cpp_class_is_valuetype", api.class_is_valuetype);

    ok &= loadSym(handle, "il2cpp_class_get_fields", api.class_get_fields);
    ok &= loadSym(handle, "il2cpp_field_get_name", api.field_get_name);
    ok &= loadSym(handle, "il2cpp_field_get_offset", api.field_get_offset);
    ok &= loadSym(handle, "il2cpp_field_get_type", api.field_get_type);
    ok &= loadSym(handle, "il2cpp_field_get_flags", api.field_get_flags);

    ok &= loadSym(handle, "il2cpp_class_get_methods", api.class_get_methods);
    ok &= loadSym(handle, "il2cpp_method_get_name", api.method_get_name);
    ok &= loadSym(handle, "il2cpp_method_get_return_type", api.method_get_return_type);
    ok &= loadSym(handle, "il2cpp_method_get_param_count", api.method_get_param_count);
    ok &= loadSym(handle, "il2cpp_method_get_param", api.method_get_param);
    ok &= loadSym(handle, "il2cpp_method_get_param_name", api.method_get_param_name);
    ok &= loadSym(handle, "il2cpp_method_get_flags", api.method_get_flags);
    ok &= loadSym(handle, "il2cpp_method_get_class", api.method_get_class);

    ok &= loadSym(handle, "il2cpp_type_get_name", api.type_get_name);
    ok &= loadSym(handle, "il2cpp_type_get_type", api.type_get_type);

    // Optional / version-dependent
    loadSym(handle, "il2cpp_class_is_generic", api.class_is_generic);
    loadSym(handle, "il2cpp_class_get_flags", api.class_get_flags);
    loadSym(handle, "il2cpp_class_get_type", api.class_get_type);
    loadSym(handle, "il2cpp_class_instance_size", api.class_instance_size);
    loadSym(handle, "il2cpp_class_from_type", api.class_from_type);
    loadSym(handle, "il2cpp_class_get_properties", api.class_get_properties);
    loadSym(handle, "il2cpp_property_get_name", api.property_get_name);
    loadSym(handle, "il2cpp_property_get_get_method", api.property_get_get_method);
    loadSym(handle, "il2cpp_property_get_set_method", api.property_get_set_method);
    loadSym(handle, "il2cpp_thread_current", api.thread_current);
    loadSym(handle, "il2cpp_is_vm_thread", api.is_vm_thread);
    loadSym(handle, "il2cpp_thread_attach", api.thread_attach);
    loadSym(handle, "il2cpp_class_for_each", api.class_for_each);

    if (!api.domain_get || !api.domain_get_assemblies || !api.assembly_get_image ||
        !api.class_get_name || !api.class_get_fields || !api.class_get_methods) {
        LOGE("Critical IL2CPP APIs missing — cannot continue");
        return false;
    }

    api.resolved = true;
    LOGI("IL2CPP API resolved successfully (core symbols present)");
    return true;
}

// MethodInfo layout (common across many Unity versions):
// struct MethodInfo {
//   void* methodPointer;          // +0
//   void* virtualMethodPointer;   // +8 (sometimes)
//   void* invoker_method;
//   const char* name;
//   ...
// };
// We take the first pointer-sized field as the method pointer.
uintptr_t getMethodPointer(const MethodInfo* method) {
    if (!method) return 0;
    SAFE_CALL_BEGIN();
    // First field is almost always the method pointer
    uintptr_t ptr = *reinterpret_cast<const uintptr_t*>(method);
    return ptr;
    SAFE_CALL_END(0);
}

uintptr_t getImageBase(const Il2CppApi& api) {
    return api.base;
}

} // namespace ApiResolver
