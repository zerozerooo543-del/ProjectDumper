#include "mem_reader.h"
#include "crash_handler.h"
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <cstring>
#include <algorithm>
#include <cctype>

namespace MemReader {

static std::string toLower(const std::string& s) {
    std::string r = s;
    std::transform(r.begin(), r.end(), r.begin(),
                   [](unsigned char c){ return std::tolower(c); });
    return r;
}

std::vector<MapEntry> parseMaps(const char* mapsPath) {
    std::vector<MapEntry> entries;
    std::ifstream ifs(mapsPath);
    if (!ifs.is_open()) {
        LOGE("Cannot open %s", mapsPath);
        return entries;
    }

    std::string line;
    while (std::getline(ifs, line)) {
        // format: start-end perms offset dev inode pathname
        MapEntry e{};
        char perms[8] = {};
        char path[512] = {};
        unsigned long long start = 0, end = 0, offset = 0, inode = 0;
        int dev_major = 0, dev_minor = 0;

        int n = sscanf(line.c_str(), "%llx-%llx %7s %llx %x:%x %llu %511[^\n]",
                       &start, &end, perms, &offset, &dev_major, &dev_minor, &inode, path);
        if (n < 7) continue;

        e.start = static_cast<uintptr_t>(start);
        e.end   = static_cast<uintptr_t>(end);
        e.perms = perms;
        e.is_readable   = (perms[0] == 'r');
        e.is_executable = (perms[2] == 'x');
        if (n >= 8) {
            // trim leading spaces from path
            char* p = path;
            while (*p == ' ') ++p;
            e.path = p;
        }
        entries.push_back(std::move(e));
    }
    return entries;
}

bool findLibrary(const std::string& libName, uintptr_t& outBase, uintptr_t& outEnd, std::string& outPath) {
    auto maps = parseMaps();
    std::string target = toLower(libName);

    // Prefer exact basename match, then contains
    for (const auto& m : maps) {
        if (m.path.empty()) continue;
        // extract basename
        auto pos = m.path.find_last_of('/');
        std::string base = (pos == std::string::npos) ? m.path : m.path.substr(pos + 1);
        if (toLower(base) == target) {
            outBase = m.start;
            outEnd  = m.end;
            outPath = m.path;
            return true;
        }
    }
    // fallback: path contains libName
    for (const auto& m : maps) {
        if (m.path.empty()) continue;
        if (toLower(m.path).find(target) != std::string::npos) {
            outBase = m.start;
            outEnd  = m.end;
            outPath = m.path;
            return true;
        }
    }
    return false;
}

bool waitForLibrary(const std::string& libName, int timeoutSec, uintptr_t& outBase, std::string& outPath) {
    const int intervalMs = 500;
    int elapsed = 0;
    uintptr_t end = 0;
    while (elapsed < timeoutSec * 1000) {
        if (findLibrary(libName, outBase, end, outPath)) {
            LOGI("Found library %s at 0x%zx path=%s", libName.c_str(), (size_t)outBase, outPath.c_str());
            return true;
        }
        usleep(intervalMs * 1000);
        elapsed += intervalMs;
    }
    LOGE("Timeout waiting for library %s", libName.c_str());
    return false;
}

uintptr_t getModuleBase(const std::string& libName) {
    uintptr_t base = 0, end = 0;
    std::string path;
    if (findLibrary(libName, base, end, path)) return base;
    return 0;
}

bool isExecutableAddress(uintptr_t addr) {
    auto maps = parseMaps();
    for (const auto& m : maps) {
        if (m.is_executable && addr >= m.start && addr < m.end) return true;
    }
    return false;
}

std::vector<uint8_t> readMemory(uintptr_t addr, size_t size) {
    std::vector<uint8_t> buf(size);
    SAFE_CALL_BEGIN();
    memcpy(buf.data(), reinterpret_cast<const void*>(addr), size);
    SAFE_CALL_END(std::vector<uint8_t>());
    return buf;
}

} // namespace MemReader
