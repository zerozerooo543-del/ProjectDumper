// Convenience umbrella header
#pragma once
#include "il2cpp_api_resolver.h"
#include "il2cpp_dumper.h"
#include "mem_reader.h"
#include "crash_handler.h"
