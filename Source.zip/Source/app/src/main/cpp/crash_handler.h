#pragma once

#include <signal.h>
#include <setjmp.h>
#include <android/log.h>

#define LOG_TAG "Il2CppDumper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace CrashHandler {

bool install();
void uninstall();

// Use these macros to wrap potentially crashing IL2CPP API calls
extern thread_local sigjmp_buf jump_buffer;
extern thread_local volatile bool jump_ready;

#define SAFE_CALL_BEGIN() \
    do { \
        CrashHandler::jump_ready = true; \
        if (sigsetjmp(CrashHandler::jump_buffer, 1) == 0) {

#define SAFE_CALL_END(default_value) \
        } else { \
            LOGE("Caught crash in IL2CPP call, recovering"); \
            CrashHandler::jump_ready = false; \
            return (default_value); \
        } \
        CrashHandler::jump_ready = false; \
    } while(0)

#define SAFE_CALL_VOID_BEGIN() \
    do { \
        CrashHandler::jump_ready = true; \
        if (sigsetjmp(CrashHandler::jump_buffer, 1) == 0) {

#define SAFE_CALL_VOID_END() \
        } else { \
            LOGE("Caught crash in IL2CPP call, recovering"); \
            CrashHandler::jump_ready = false; \
            return; \
        } \
        CrashHandler::jump_ready = false; \
    } while(0)

} // namespace CrashHandler
