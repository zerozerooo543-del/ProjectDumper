#pragma once

#include "il2cpp_api_resolver.h"
#include <string>
#include <functional>
#include <atomic>

using ProgressCallback = std::function<void(int current, int total, const std::string& status)>;
using LogCallback     = std::function<void(const std::string& line)>;

class Il2CppDumper {
public:
    Il2CppDumper();
    ~Il2CppDumper();

    // Configure before start
    void setLibName(const std::string& name);
    void setMetadataName(const std::string& name); // informational only (we dump live state)
    void setOutputPath(const std::string& path);
    void setProgressCallback(ProgressCallback cb);
    void setLogCallback(LogCallback cb);

    // Main entry — blocks until dump finishes or fails
    // Returns path of dump.cs on success, empty string on failure
    std::string startDump();

    void requestStop();
    bool isRunning() const;

private:
    std::string libName_;
    std::string metadataName_;
    std::string outputPath_;
    ProgressCallback progressCb_;
    LogCallback logCb_;
    std::atomic<bool> stopRequested_{false};
    std::atomic<bool> running_{false};

    Il2CppApi api_;

    void log(const std::string& msg);
    void progress(int cur, int total, const std::string& status);

    bool waitForIl2CppReady(int timeoutSec);
    bool enumerateAndDump(const std::string& outFile);

    // Helpers for dump.cs formatting
    std::string typeName(const Il2CppType* type);
    std::string accessModifiers(uint32_t flags, bool isField);
    std::string dumpClass(Il2CppClass* klass, const std::string& imageName);
    std::string dumpFields(Il2CppClass* klass);
    std::string dumpMethods(Il2CppClass* klass);
    std::string dumpProperties(Il2CppClass* klass);
};
