#pragma once

#include <string>
#include <vector>
#include <cstdint>

struct MapEntry {
    uintptr_t start;
    uintptr_t end;
    std::string perms;
    std::string path;
    bool is_executable;
    bool is_readable;
};

namespace MemReader {

// Parse /proc/self/maps (or given maps path)
std::vector<MapEntry> parseMaps(const char* mapsPath = "/proc/self/maps");

// Find first mapping that contains the given library name (basename match)
bool findLibrary(const std::string& libName, uintptr_t& outBase, uintptr_t& outEnd, std::string& outPath);

// Wait until library appears in maps (poll every 500ms, timeout seconds)
bool waitForLibrary(const std::string& libName, int timeoutSec, uintptr_t& outBase, std::string& outPath);

// Get base address of a loaded library from maps
uintptr_t getModuleBase(const std::string& libName);

// Check if address is inside any executable mapping
bool isExecutableAddress(uintptr_t addr);

// Read a range of memory safely (returns empty on failure)
std::vector<uint8_t> readMemory(uintptr_t addr, size_t size);

} // namespace MemReader
