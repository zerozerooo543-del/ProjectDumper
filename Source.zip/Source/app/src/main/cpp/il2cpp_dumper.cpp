#include "il2cpp_dumper.h"
#include "mem_reader.h"
#include "crash_handler.h"
#include <fstream>
#include <sstream>
#include <iomanip>
#include <unistd.h>
#include <vector>
#include <unordered_set>

// Field attributes (from CorFieldAttr)
static const uint32_t FIELD_ATTRIBUTE_PRIVATE   = 0x0001;
static const uint32_t FIELD_ATTRIBUTE_FAM_AND_ASSEM = 0x0002;
static const uint32_t FIELD_ATTRIBUTE_ASSEMBLY  = 0x0003;
static const uint32_t FIELD_ATTRIBUTE_FAMILY    = 0x0004;
static const uint32_t FIELD_ATTRIBUTE_FAM_OR_ASSEM = 0x0005;
static const uint32_t FIELD_ATTRIBUTE_PUBLIC    = 0x0006;
static const uint32_t FIELD_ATTRIBUTE_STATIC    = 0x0010;
static const uint32_t FIELD_ATTRIBUTE_INIT_ONLY = 0x0020;
static const uint32_t FIELD_ATTRIBUTE_LITERAL   = 0x0040;

// Method attributes
static const uint32_t METHOD_ATTRIBUTE_PRIVATE  = 0x0001;
static const uint32_t METHOD_ATTRIBUTE_PUBLIC   = 0x0006;
static const uint32_t METHOD_ATTRIBUTE_STATIC   = 0x0010;
static const uint32_t METHOD_ATTRIBUTE_VIRTUAL  = 0x0040;
static const uint32_t METHOD_ATTRIBUTE_ABSTRACT = 0x0400;

Il2CppDumper::Il2CppDumper() = default;
Il2CppDumper::~Il2CppDumper() {
    requestStop();
}

void Il2CppDumper::setLibName(const std::string& name) { libName_ = name; }
void Il2CppDumper::setMetadataName(const std::string& name) { metadataName_ = name; }
void Il2CppDumper::setOutputPath(const std::string& path) { outputPath_ = path; }
void Il2CppDumper::setProgressCallback(ProgressCallback cb) { progressCb_ = std::move(cb); }
void Il2CppDumper::setLogCallback(LogCallback cb) { logCb_ = std::move(cb); }

void Il2CppDumper::requestStop() { stopRequested_ = true; }
bool Il2CppDumper::isRunning() const { return running_; }

void Il2CppDumper::log(const std::string& msg) {
    LOGI("%s", msg.c_str());
    if (logCb_) logCb_(msg);
}

void Il2CppDumper::progress(int cur, int total, const std::string& status) {
    if (progressCb_) progressCb_(cur, total, status);
}

std::string Il2CppDumper::startDump() {
    if (running_) {
        log("Dump already running");
        return "";
    }
    running_ = true;
    stopRequested_ = false;
    std::string resultPath;

    CrashHandler::install();

    do {
        if (libName_.empty()) {
            log("Library name is empty");
            break;
        }
        if (outputPath_.empty()) {
            log("Output path is empty");
            break;
        }

        log("Waiting for library: " + libName_);
        progress(0, 0, "Menunggu library ter-load...");

        uintptr_t base = 0;
        std::string libPath;
        if (!MemReader::waitForLibrary(libName_, 120, base, libPath)) {
            log("Library not found in maps within timeout");
            break;
        }
        log("Library found: " + libPath);

        log("Resolving IL2CPP APIs via dlsym...");
        if (!ApiResolver::resolve(libName_, api_)) {
            // try basename only
            auto pos = libName_.find_last_of('/');
            std::string baseName = (pos == std::string::npos) ? libName_ : libName_.substr(pos + 1);
            if (!ApiResolver::resolve(baseName, api_)) {
                log("Failed to resolve IL2CPP APIs");
                break;
            }
        }

        log("Waiting for IL2CPP domain ready...");
        progress(0, 0, "Menunggu IL2CPP ready...");
        if (!waitForIl2CppReady(90)) {
            log("IL2CPP domain never became ready");
            break;
        }

        // Attach current thread if possible
        if (api_.thread_attach && api_.domain_get) {
            SAFE_CALL_VOID_BEGIN();
            auto* domain = api_.domain_get();
            if (domain) api_.thread_attach(domain);
            SAFE_CALL_VOID_END();
        }

        log("Starting class enumeration & dump...");
        if (enumerateAndDump(outputPath_)) {
            resultPath = outputPath_;
            log("Dump completed: " + resultPath);
            progress(100, 100, "Selesai");
        } else {
            log("Dump failed during enumeration");
        }
    } while (false);

    CrashHandler::uninstall();
    running_ = false;
    return resultPath;
}

bool Il2CppDumper::waitForIl2CppReady(int timeoutSec) {
    const int intervalMs = 500;
    int elapsed = 0;
    while (elapsed < timeoutSec * 1000 && !stopRequested_) {
        if (api_.domain_get) {
            SAFE_CALL_BEGIN();
            auto* domain = api_.domain_get();
            if (domain != nullptr) {
                // further check: try get assemblies
                if (api_.domain_get_assemblies) {
                    size_t size = 0;
                    auto** asms = api_.domain_get_assemblies(domain, &size);
                    if (asms && size > 0) {
                        log("IL2CPP ready — assemblies count = " + std::to_string(size));
                        return true;
                    }
                } else {
                    return true;
                }
            }
            SAFE_CALL_END(false);
        }
        usleep(intervalMs * 1000);
        elapsed += intervalMs;
    }
    return false;
}

std::string Il2CppDumper::typeName(const Il2CppType* type) {
    if (!type || !api_.type_get_name) return "Object";
    SAFE_CALL_BEGIN();
    const char* n = api_.type_get_name(type);
    if (n && n[0]) return std::string(n);
    SAFE_CALL_END(std::string("Object"));
    return "Object";
}

std::string Il2CppDumper::accessModifiers(uint32_t flags, bool isField) {
    std::string s;
    uint32_t access = flags & 0x7;
    switch (access) {
        case FIELD_ATTRIBUTE_PRIVATE:   s += "private "; break;
        case FIELD_ATTRIBUTE_FAMILY:    s += "protected "; break;
        case FIELD_ATTRIBUTE_ASSEMBLY:
        case FIELD_ATTRIBUTE_FAM_AND_ASSEM: s += "internal "; break;
        case FIELD_ATTRIBUTE_FAM_OR_ASSEM: s += "protected internal "; break;
        case FIELD_ATTRIBUTE_PUBLIC:    s += "public "; break;
        default: s += "private "; break;
    }
    if (flags & FIELD_ATTRIBUTE_STATIC) s += "static ";
    if (isField) {
        if (flags & FIELD_ATTRIBUTE_INIT_ONLY) s += "readonly ";
        if (flags & FIELD_ATTRIBUTE_LITERAL)   s += "const ";
    } else {
        if (flags & METHOD_ATTRIBUTE_VIRTUAL)  s += "virtual ";
        if (flags & METHOD_ATTRIBUTE_ABSTRACT) s += "abstract ";
    }
    return s;
}

std::string Il2CppDumper::dumpFields(Il2CppClass* klass) {
    std::ostringstream oss;
    if (!api_.class_get_fields || !api_.field_get_name) return "";

    void* iter = nullptr;
    FieldInfo* field = nullptr;
    SAFE_CALL_BEGIN();
    while ((field = api_.class_get_fields(klass, &iter)) != nullptr) {
        if (stopRequested_) break;

        const char* name = api_.field_get_name(field);
        if (!name) name = "<unknown>";

        size_t offset = 0;
        if (api_.field_get_offset) {
            offset = api_.field_get_offset(field);
        }

        uint32_t flags = 0;
        if (api_.field_get_flags) {
            flags = static_cast<uint32_t>(api_.field_get_flags(field));
        }

        std::string tname = "Object";
        if (api_.field_get_type) {
            auto* t = api_.field_get_type(field);
            tname = typeName(t);
        }

        // simple demangle of generic markers for readability
        // keep as-is for accuracy with Il2CppDumper style
        oss << "\t" << accessModifiers(flags, true) << tname << " " << name
            << "; // 0x" << std::hex << offset << std::dec << "\n";
    }
    SAFE_CALL_END(std::string());
    return oss.str();
}

std::string Il2CppDumper::dumpMethods(Il2CppClass* klass) {
    std::ostringstream oss;
    if (!api_.class_get_methods || !api_.method_get_name) return "";

    void* iter = nullptr;
    const MethodInfo* method = nullptr;
    uintptr_t imageBase = api_.base;

    SAFE_CALL_BEGIN();
    while ((method = api_.class_get_methods(klass, &iter)) != nullptr) {
        if (stopRequested_) break;

        const char* name = api_.method_get_name(method);
        if (!name) name = "<unknown>";

        uint32_t iflags = 0;
        uint32_t flags = 0;
        if (api_.method_get_flags) {
            flags = api_.method_get_flags(method, &iflags);
        }

        std::string retType = "void";
        if (api_.method_get_return_type) {
            retType = typeName(api_.method_get_return_type(method));
        }

        // Parameters
        std::ostringstream params;
        uint32_t pcount = 0;
        if (api_.method_get_param_count) {
            pcount = api_.method_get_param_count(method);
        }
        for (uint32_t i = 0; i < pcount; ++i) {
            if (i > 0) params << ", ";
            std::string pname = "arg" + std::to_string(i);
            if (api_.method_get_param_name) {
                const char* pn = api_.method_get_param_name(method, i);
                if (pn && pn[0]) pname = pn;
            }
            std::string ptype = "Object";
            if (api_.method_get_param) {
                ptype = typeName(api_.method_get_param(method, i));
            }
            params << ptype << " " << pname;
        }

        uintptr_t methodPtr = ApiResolver::getMethodPointer(method);
        uintptr_t rva = 0;
        uintptr_t va  = methodPtr;
        uintptr_t offset = 0;
        if (methodPtr && imageBase && methodPtr >= imageBase) {
            rva = methodPtr - imageBase;
            offset = rva; // simplified; real file offset would need ELF parsing
        }

        oss << "\t// RVA: 0x" << std::hex << rva
            << " Offset: 0x" << offset
            << " VA: 0x" << va << std::dec << "\n";
        oss << "\t" << accessModifiers(flags, false) << retType << " " << name
            << "(" << params.str() << ") { }\n\n";
    }
    SAFE_CALL_END(std::string());
    return oss.str();
}

std::string Il2CppDumper::dumpProperties(Il2CppClass* klass) {
    std::ostringstream oss;
    if (!api_.class_get_properties || !api_.property_get_name) return "";

    void* iter = nullptr;
    const PropertyInfo* prop = nullptr;
    SAFE_CALL_BEGIN();
    while ((prop = api_.class_get_properties(klass, &iter)) != nullptr) {
        if (stopRequested_) break;
        const char* name = api_.property_get_name(const_cast<PropertyInfo*>(prop));
        if (!name) name = "<unknown>";
        oss << "\t// Property: " << name << "\n";
    }
    SAFE_CALL_END(std::string());
    return oss.str();
}

std::string Il2CppDumper::dumpClass(Il2CppClass* klass, const std::string& imageName) {
    if (!klass) return "";

    std::ostringstream oss;
    SAFE_CALL_BEGIN();

    const char* name = api_.class_get_name ? api_.class_get_name(klass) : nullptr;
    const char* ns   = api_.class_get_namespace ? api_.class_get_namespace(klass) : nullptr;
    if (!name) name = "<Unknown>";
    if (!ns) ns = "";

    bool isEnum = api_.class_is_enum ? api_.class_is_enum(klass) : false;
    bool isIface = api_.class_is_interface ? api_.class_is_interface(klass) : false;
    bool isValue = api_.class_is_valuetype ? api_.class_is_valuetype(klass) : false;

    std::string keyword = "class";
    if (isEnum) keyword = "enum";
    else if (isIface) keyword = "interface";
    else if (isValue) keyword = "struct";

    // Parent
    std::string parentStr;
    if (api_.class_get_parent) {
        auto* parent = api_.class_get_parent(klass);
        if (parent) {
            const char* pn = api_.class_get_name(parent);
            const char* pns = api_.class_get_namespace(parent);
            if (pn) {
                if (pns && pns[0]) parentStr = std::string(pns) + "." + pn;
                else parentStr = pn;
            }
        }
    }

    oss << "// Dll : " << imageName << "\n";
    if (ns[0]) oss << "// Namespace: " << ns << "\n";
    else oss << "// Namespace: \n";

    oss << "public " << keyword << " " << name;
    if (!parentStr.empty() && parentStr != "Object" && parentStr != "System.Object") {
        oss << " : " << parentStr;
    }
    oss << "\n{\n";

    // Fields
    std::string fields = dumpFields(klass);
    if (!fields.empty()) {
        oss << "\t// Fields\n" << fields << "\n";
    }

    // Properties
    std::string props = dumpProperties(klass);
    if (!props.empty()) {
        oss << "\t// Properties\n" << props << "\n";
    }

    // Methods
    std::string methods = dumpMethods(klass);
    if (!methods.empty()) {
        oss << "\t// Methods\n" << methods;
    }

    oss << "}\n\n";
    SAFE_CALL_END(std::string());
    return oss.str();
}

bool Il2CppDumper::enumerateAndDump(const std::string& outFile) {
    std::ofstream ofs(outFile, std::ios::out | std::ios::trunc);
    if (!ofs.is_open()) {
        log("Cannot open output file: " + outFile);
        return false;
    }

    ofs << "// Generated by Il2Cpp Runtime Dumper (in-process)\n";
    ofs << "// Library: " << libName_ << "\n";
    ofs << "// Metadata hint: " << metadataName_ << "\n\n";

    if (!api_.domain_get || !api_.domain_get_assemblies) {
        log("Missing domain APIs");
        return false;
    }

    Il2CppDomain* domain = nullptr;
    SAFE_CALL_BEGIN();
    domain = api_.domain_get();
    SAFE_CALL_END(false);
    if (!domain) {
        log("domain_get returned null");
        return false;
    }

    size_t assemblyCount = 0;
    const Il2CppAssembly** assemblies = nullptr;
    SAFE_CALL_BEGIN();
    assemblies = api_.domain_get_assemblies(domain, &assemblyCount);
    SAFE_CALL_END(false);

    if (!assemblies || assemblyCount == 0) {
        log("No assemblies found");
        return false;
    }

    log("Found " + std::to_string(assemblyCount) + " assemblies");

    // First pass: count classes for progress
    size_t totalClasses = 0;
    std::vector<std::pair<Il2CppImage*, std::string>> images;
    for (size_t i = 0; i < assemblyCount && !stopRequested_; ++i) {
        if (!assemblies[i] || !api_.assembly_get_image) continue;
        Il2CppImage* image = nullptr;
        SAFE_CALL_BEGIN();
        image = api_.assembly_get_image(assemblies[i]);
        SAFE_CALL_END(false);
        if (!image) continue;

        std::string imgName = "Unknown.dll";
        if (api_.image_get_name) {
            SAFE_CALL_BEGIN();
            const char* n = api_.image_get_name(image);
            if (n) imgName = n;
            SAFE_CALL_END(false);
        }

        size_t count = 0;
        if (api_.image_get_class_count) {
            SAFE_CALL_BEGIN();
            count = api_.image_get_class_count(image);
            SAFE_CALL_END(false);
        }
        totalClasses += count;
        images.emplace_back(image, imgName);
    }

    log("Total classes to dump: " + std::to_string(totalClasses));
    progress(0, static_cast<int>(totalClasses), "Dumping classes...");

    size_t dumped = 0;
    std::unordered_set<Il2CppClass*> seen;

    for (auto& [image, imgName] : images) {
        if (stopRequested_) break;
        if (!api_.image_get_class_count || !api_.image_get_class) continue;

        size_t count = 0;
        SAFE_CALL_BEGIN();
        count = api_.image_get_class_count(image);
        SAFE_CALL_END(false);

        for (size_t c = 0; c < count && !stopRequested_; ++c) {
            Il2CppClass* klass = nullptr;
            SAFE_CALL_BEGIN();
            klass = api_.image_get_class(image, c);
            SAFE_CALL_END(false);
            if (!klass) continue;
            if (seen.count(klass)) continue;
            seen.insert(klass);

            std::string text = dumpClass(klass, imgName);
            if (!text.empty()) {
                ofs << text;
                ofs.flush(); // incremental write
            }
            ++dumped;
            if (dumped % 50 == 0 || dumped == totalClasses) {
                progress(static_cast<int>(dumped), static_cast<int>(totalClasses),
                         "Dumping " + std::to_string(dumped) + "/" + std::to_string(totalClasses) + " classes");
            }
        }
    }

    // Fallback: class_for_each if available and we got very few classes
    if (dumped < 10 && api_.class_for_each && !stopRequested_) {
        log("Low class count, trying class_for_each fallback...");
        struct Ctx {
            Il2CppDumper* self;
            std::ofstream* ofs;
            std::unordered_set<Il2CppClass*>* seen;
            size_t* dumped;
        } ctx{this, &ofs, &seen, &dumped};

        auto cb = [](Il2CppClass* klass, void* user) {
            auto* c = static_cast<Ctx*>(user);
            if (!klass || c->seen->count(klass)) return;
            c->seen->insert(klass);
            std::string text = c->self->dumpClass(klass, "Runtime");
            if (!text.empty()) {
                (*c->ofs) << text;
                c->ofs->flush();
            }
            (*c->dumped)++;
        };
        SAFE_CALL_VOID_BEGIN();
        api_.class_for_each(cb, &ctx);
        SAFE_CALL_VOID_END();
    }

    ofs.close();
    log("Wrote " + std::to_string(dumped) + " classes to " + outFile);
    return dumped > 0;
}
