#include <jni.h>
#include <string>
#include <thread>
#include <mutex>
#include <atomic>
#include <memory>
#include "il2cpp_dumper.h"
#include "crash_handler.h"

static JavaVM* g_vm = nullptr;
static std::mutex g_mutex;
static std::atomic<bool> g_running{false};

// Global dumper instance for the current dump session
static std::unique_ptr<Il2CppDumper> g_dumper;

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

static std::string jstringToString(JNIEnv* env, jstring js) {
    if (!js) return "";
    const char* chars = env->GetStringUTFChars(js, nullptr);
    std::string s = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(js, chars);
    return s;
}

// Callback helpers that attach JNIEnv if needed
static void callJavaProgress(jobject callback, int current, int total, const std::string& status) {
    if (!g_vm || !callback) return;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        attached = true;
    }
    jclass cls = env->GetObjectClass(callback);
    if (cls) {
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(IILjava/lang/String;)V");
        if (mid) {
            jstring jstatus = env->NewStringUTF(status.c_str());
            env->CallVoidMethod(callback, mid, current, total, jstatus);
            env->DeleteLocalRef(jstatus);
        }
        env->DeleteLocalRef(cls);
    }
    if (attached) g_vm->DetachCurrentThread();
}

static void callJavaLog(jobject callback, const std::string& line) {
    if (!g_vm || !callback) return;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        attached = true;
    }
    jclass cls = env->GetObjectClass(callback);
    if (cls) {
        jmethodID mid = env->GetMethodID(cls, "onLog", "(Ljava/lang/String;)V");
        if (mid) {
            jstring jline = env->NewStringUTF(line.c_str());
            env->CallVoidMethod(callback, mid, jline);
            env->DeleteLocalRef(jline);
        }
        env->DeleteLocalRef(cls);
    }
    if (attached) g_vm->DetachCurrentThread();
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_il2cpp_runtimedumper_NativeDumper_startDump(
        JNIEnv* env, jobject /*thiz*/,
        jstring jLibName,
        jstring jMetadataName,
        jstring jOutputPath,
        jobject jCallback) {

    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_running) {
        return env->NewStringUTF("ERROR: already running");
    }
    g_running = true;

    std::string libName = jstringToString(env, jLibName);
    std::string metaName = jstringToString(env, jMetadataName);
    std::string outPath = jstringToString(env, jOutputPath);

    // Global ref for callback so it survives across threads
    jobject callback = jCallback ? env->NewGlobalRef(jCallback) : nullptr;

    g_dumper = std::make_unique<Il2CppDumper>();
    g_dumper->setLibName(libName);
    g_dumper->setMetadataName(metaName);
    g_dumper->setOutputPath(outPath);

    if (callback) {
        g_dumper->setProgressCallback([callback](int cur, int total, const std::string& st) {
            callJavaProgress(callback, cur, total, st);
        });
        g_dumper->setLogCallback([callback](const std::string& line) {
            callJavaLog(callback, line);
        });
    }

    // Run dump on a dedicated thread so we don't block the caller forever,
    // but for simplicity of JNI contract we still join here (caller should
    // invoke from a background coroutine/thread).
    std::string result;
    std::thread worker([&]() {
        result = g_dumper->startDump();
    });
    worker.join();

    if (callback) {
        env->DeleteGlobalRef(callback);
    }
    g_dumper.reset();
    g_running = false;

    if (result.empty()) {
        return env->NewStringUTF("ERROR: dump failed");
    }
    return env->NewStringUTF(result.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_il2cpp_runtimedumper_NativeDumper_stopDump(JNIEnv*, jobject) {
    if (g_dumper) {
        g_dumper->requestStop();
    }
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_il2cpp_runtimedumper_NativeDumper_isRunning(JNIEnv*, jobject) {
    return g_running ? JNI_TRUE : JNI_FALSE;
}
