#include "crash_handler.h"
#include <unistd.h>
#include <cstring>
#include <pthread.h>

namespace CrashHandler {

thread_local sigjmp_buf jump_buffer;
thread_local volatile bool jump_ready = false;

static struct sigaction old_segv;
static struct sigaction old_bus;
static stack_t alt_stack;
static bool installed = false;

static void signal_handler(int sig, siginfo_t* info, void* context) {
    if (jump_ready) {
        jump_ready = false;
        siglongjmp(jump_buffer, 1);
    }
    // Not in protected region — restore and re-raise
    if (sig == SIGSEGV && old_segv.sa_sigaction) {
        old_segv.sa_sigaction(sig, info, context);
    } else if (sig == SIGBUS && old_bus.sa_sigaction) {
        old_bus.sa_sigaction(sig, info, context);
    } else {
        signal(sig, SIG_DFL);
        raise(sig);
    }
}

bool install() {
    if (installed) return true;

    // Alternate stack so handler works even if main stack is broken
    alt_stack.ss_sp = malloc(SIGSTKSZ * 4);
    if (!alt_stack.ss_sp) {
        LOGE("Failed to allocate alt signal stack");
        return false;
    }
    alt_stack.ss_size = SIGSTKSZ * 4;
    alt_stack.ss_flags = 0;
    if (sigaltstack(&alt_stack, nullptr) != 0) {
        LOGE("sigaltstack failed");
        free(alt_stack.ss_sp);
        return false;
    }

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = signal_handler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK | SA_NODEFER;
    sigemptyset(&sa.sa_mask);

    if (sigaction(SIGSEGV, &sa, &old_segv) != 0) {
        LOGE("Failed to install SIGSEGV handler");
        return false;
    }
    if (sigaction(SIGBUS, &sa, &old_bus) != 0) {
        LOGE("Failed to install SIGBUS handler");
        sigaction(SIGSEGV, &old_segv, nullptr);
        return false;
    }

    installed = true;
    LOGI("Crash handler installed (SIGSEGV/SIGBUS on alt stack)");
    return true;
}

void uninstall() {
    if (!installed) return;
    sigaction(SIGSEGV, &old_segv, nullptr);
    sigaction(SIGBUS, &old_bus, nullptr);
    if (alt_stack.ss_sp) {
        stack_t disable = {};
        disable.ss_flags = SS_DISABLE;
        sigaltstack(&disable, nullptr);
        free(alt_stack.ss_sp);
        alt_stack.ss_sp = nullptr;
    }
    installed = false;
    LOGI("Crash handler uninstalled");
}

} // namespace CrashHandler
