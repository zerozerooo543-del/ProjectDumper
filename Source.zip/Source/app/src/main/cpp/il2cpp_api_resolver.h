#pragma once

#include <cstdint>
#include <cstddef>
#include <string>

// Opaque IL2CPP types
using Il2CppDomain   = void;
using Il2CppAssembly = void;
using Il2CppImage    = void;
using Il2CppClass    = void;
using FieldInfo      = void;
using MethodInfo     = void;
using Il2CppType     = void;
using PropertyInfo   = void;
using Il2CppThread   = void;

struct Il2CppApi {
    // Domain & Assembly
    Il2CppDomain*   (*domain_get)();
    const Il2CppAssembly** (*domain_get_assemblies)(const Il2CppDomain* domain, size_t* size);
    Il2CppImage*    (*assembly_get_image)(const Il2CppAssembly* assembly);

    // Image
    const char*     (*image_get_name)(const Il2CppImage* image);
    size_t          (*image_get_class_count)(const Il2CppImage* image);
    Il2CppClass*    (*image_get_class)(const Il2CppImage* image, size_t index);

    // Class
    const char*     (*class_get_name)(Il2CppClass* klass);
    const char*     (*class_get_namespace)(Il2CppClass* klass);
    Il2CppClass*    (*class_get_parent)(Il2CppClass* klass);
    bool            (*class_is_enum)(const Il2CppClass* klass);
    bool            (*class_is_interface)(const Il2CppClass* klass);
    bool            (*class_is_valuetype)(const Il2CppClass* klass);
    bool            (*class_is_generic)(const Il2CppClass* klass);
    int             (*class_get_flags)(const Il2CppClass* klass);
    Il2CppType*     (*class_get_type)(Il2CppClass* klass);
    uint32_t        (*class_instance_size)(Il2CppClass* klass);

    // Fields
    FieldInfo*      (*class_get_fields)(Il2CppClass* klass, void** iter);
    const char*     (*field_get_name)(FieldInfo* field);
    size_t          (*field_get_offset)(FieldInfo* field);
    Il2CppType*     (*field_get_type)(FieldInfo* field);
    int             (*field_get_flags)(FieldInfo* field);

    // Methods
    const MethodInfo* (*class_get_methods)(Il2CppClass* klass, void** iter);
    const char*     (*method_get_name)(const MethodInfo* method);
    Il2CppType*     (*method_get_return_type)(const MethodInfo* method);
    uint32_t        (*method_get_param_count)(const MethodInfo* method);
    Il2CppType*     (*method_get_param)(const MethodInfo* method, uint32_t index);
    const char*     (*method_get_param_name)(const MethodInfo* method, uint32_t index);
    uint32_t        (*method_get_flags)(const MethodInfo* method, uint32_t* iflags);
    Il2CppClass*    (*method_get_class)(const MethodInfo* method);
    // method pointer is usually at offset 0 of MethodInfo in most Unity versions
    // we expose a helper later

    // Type
    const char*     (*type_get_name)(const Il2CppType* type);
    int             (*type_get_type)(const Il2CppType* type);
    Il2CppClass*    (*class_from_type)(const Il2CppType* type);

    // Properties
    const PropertyInfo* (*class_get_properties)(Il2CppClass* klass, void** iter);
    const char*     (*property_get_name)(PropertyInfo* prop);
    const MethodInfo* (*property_get_get_method)(PropertyInfo* prop);
    const MethodInfo* (*property_get_set_method)(PropertyInfo* prop);

    // Thread / init helpers
    Il2CppThread*   (*thread_current)();
    bool            (*is_vm_thread)(Il2CppThread* thread);
    void            (*thread_attach)(Il2CppDomain* domain);

    // Newer API (optional)
    void            (*class_for_each)(void (*func)(Il2CppClass* klass, void* user), void* userData);

    void* handle = nullptr; // dlopen handle
    uintptr_t base = 0;
    bool resolved = false;
};

namespace ApiResolver {

// Resolve all required symbols from the given library (must already be loaded)
bool resolve(const std::string& libName, Il2CppApi& api);

// Helper to get method pointer (RVA) from MethodInfo*
// Works across common Unity IL2CPP layouts
uintptr_t getMethodPointer(const MethodInfo* method);

// Get image base of the IL2CPP library for RVA calculation
uintptr_t getImageBase(const Il2CppApi& api);

} // namespace ApiResolver
