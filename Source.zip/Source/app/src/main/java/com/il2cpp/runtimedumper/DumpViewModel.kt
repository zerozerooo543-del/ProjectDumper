package com.il2cpp.runtimedumper

import android.app.Application
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.il2cpp.runtimedumper.scanner.PidScanner
import com.il2cpp.runtimedumper.scanner.ProcessInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class DumpUiState(
    val packageName: String = "",
    val libName: String = "libil2cpp.so",
    val metadataName: String = "global-metadata.dat",
    val autoScanPid: Boolean = true,
    val isScanning: Boolean = false,
    val isDumping: Boolean = false,
    val status: String = "Siap",
    val progressCurrent: Int = 0,
    val progressTotal: Int = 0,
    val logLines: List<String> = emptyList(),
    val foundProcesses: List<ProcessInfo> = emptyList(),
    val dumpPath: String? = null,
    val error: String? = null
)

class DumpViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(DumpUiState())
    val state: StateFlow<DumpUiState> = _state.asStateFlow()

    fun updatePackageName(v: String) {
        _state.value = _state.value.copy(packageName = v)
    }

    fun updateLibName(v: String) {
        _state.value = _state.value.copy(libName = v)
    }

    fun updateMetadataName(v: String) {
        _state.value = _state.value.copy(metadataName = v)
    }

    fun updateAutoScan(v: Boolean) {
        _state.value = _state.value.copy(autoScanPid = v)
    }

    fun appendLog(line: String) {
        val cur = _state.value
        _state.value = cur.copy(logLines = (cur.logLines + line).takeLast(500))
    }

    fun scanProcesses() {
        val pkg = _state.value.packageName.trim()
        if (pkg.isEmpty()) {
            _state.value = _state.value.copy(error = "Package name kosong")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _state.value = _state.value.copy(isScanning = true, error = null, status = "Scanning PID...")
            appendLog("Scanning /proc for package: $pkg")
            val list = PidScanner.scan(pkg)
            _state.value = _state.value.copy(
                isScanning = false,
                foundProcesses = list,
                status = if (list.isEmpty()) "Tidak ditemukan" else "Ditemukan ${list.size} proses"
            )
            list.forEach {
                appendLog("PID=${it.pid} UID=${it.uid} virtual=${it.isVirtual} cmd=${it.cmdline.take(80)}")
            }
        }
    }

    /**
     * In a real deployment this library is loaded INSIDE the target process
     * (via virtual-space plugin, Zygisk-less injection, or by modifying the APK).
     * From the host UI we only prepare parameters and show instructions.
     *
     * When the native library is already loaded in the current process
     * (i.e. this APK itself is running as the game inside a virtual container),
     * we can call startDump directly.
     */
    fun startDump() {
        val s = _state.value
        if (s.libName.isBlank()) {
            _state.value = s.copy(error = "Library name wajib diisi")
            return
        }

        val outDir = getOutputDir()
        outDir.mkdirs()
        val outFile = File(outDir, "dump.cs")
        val outPath = outFile.absolutePath

        viewModelScope.launch(Dispatchers.IO) {
            _state.value = _state.value.copy(
                isDumping = true,
                error = null,
                dumpPath = null,
                status = "Menunggu IL2CPP ready...",
                progressCurrent = 0,
                progressTotal = 0
            )
            appendLog("Starting dump → $outPath")
            appendLog("lib=${s.libName} meta=${s.metadataName}")

            val callback = object : NativeDumper.DumpCallback {
                override fun onProgress(current: Int, total: Int, status: String) {
                    _state.value = _state.value.copy(
                        progressCurrent = current,
                        progressTotal = total,
                        status = status
                    )
                }

                override fun onLog(line: String) {
                    appendLog(line)
                }
            }

            try {
                val result = NativeDumper.startDump(
                    s.libName.trim(),
                    s.metadataName.trim(),
                    outPath,
                    callback
                )
                if (result.startsWith("ERROR:")) {
                    _state.value = _state.value.copy(
                        isDumping = false,
                        error = result,
                        status = "Gagal"
                    )
                    appendLog(result)
                } else {
                    _state.value = _state.value.copy(
                        isDumping = false,
                        dumpPath = result,
                        status = "Selesai"
                    )
                    appendLog("Dump OK: $result")
                }
            } catch (t: Throwable) {
                _state.value = _state.value.copy(
                    isDumping = false,
                    error = t.message ?: "Unknown error",
                    status = "Error"
                )
                appendLog("Exception: ${t.message}")
            }
        }
    }

    fun stopDump() {
        try {
            NativeDumper.stopDump()
            appendLog("Stop requested")
        } catch (_: Throwable) {
        }
        _state.value = _state.value.copy(isDumping = false, status = "Dihentikan")
    }

    private fun getOutputDir(): File {
        val ctx = getApplication<Application>()
        // Prefer external files so it is accessible from host / file managers
        val ext = ctx.getExternalFilesDir(null)
        return ext ?: ctx.filesDir
    }
}
