package com.il2cpp.runtimedumper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : ComponentActivity() {

    private val vm: DumpViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    DumperApp(vm)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DumperApp(vm: DumpViewModel) {
    val state by vm.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Il2Cpp Runtime Dumper") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Config") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Progress") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Hasil") })
            }

            when (tab) {
                0 -> ConfigScreen(state, vm) { tab = 1 }
                1 -> ProgressScreen(state, vm)
                2 -> ResultScreen(state)
            }
        }
    }
}

@Composable
fun ConfigScreen(state: DumpUiState, vm: DumpViewModel, onStart: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = state.packageName,
            onValueChange = vm::updatePackageName,
            label = { Text("Nama Package Game") },
            placeholder = { Text("com.example.game") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = state.libName,
            onValueChange = vm::updateLibName,
            label = { Text("Library Name") },
            placeholder = { Text("libil2cpp.so / liblogic.so / libcsharp.so") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = state.metadataName,
            onValueChange = vm::updateMetadataName,
            label = { Text("Metadata Name (info only)") },
            placeholder = { Text("global-metadata.dat") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = state.autoScanPid,
                onCheckedChange = vm::updateAutoScan
            )
            Text("Auto-scan PID")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.scanProcesses() },
                enabled = !state.isScanning && !state.isDumping
            ) {
                Text(if (state.isScanning) "Scanning..." else "Scan PID")
            }

            Button(
                onClick = {
                    onStart()
                    vm.startDump()
                },
                enabled = !state.isDumping && state.libName.isNotBlank()
            ) {
                Text("SCAN & LOAD LIBRARY")
            }
        }

        if (state.foundProcesses.isNotEmpty()) {
            Text("Proses ditemukan:", style = MaterialTheme.typography.titleSmall)
            state.foundProcesses.take(5).forEach { p ->
                Text(
                    "PID ${p.pid}  UID ${p.uid}  virtual=${p.isVirtual}\n${p.cmdline.take(100)}",
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        if (state.error != null) {
            Text(state.error!!, color = MaterialTheme.colorScheme.error)
        }

        Text(
            "Catatan: library native harus di-load di dalam proses game " +
                    "(via virtual space / mod loader / inject). " +
                    "Jika APK ini sendiri berjalan sebagai host di dalam container yang sama, " +
                    "dump akan langsung berjalan di process ini.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun ProgressScreen(state: DumpUiState, vm: DumpViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(state.status, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        if (state.progressTotal > 0) {
            LinearProgressIndicator(
                progress = { state.progressCurrent.toFloat() / state.progressTotal.coerceAtLeast(1) },
                modifier = Modifier.fillMaxWidth()
            )
            Text("${state.progressCurrent} / ${state.progressTotal}")
        } else if (state.isDumping) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        Spacer(Modifier.height(8.dp))

        if (state.isDumping) {
            OutlinedButton(onClick = { vm.stopDump() }) {
                Text("Stop")
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("Log:", style = MaterialTheme.typography.titleSmall)

        LazyColumn(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            items(state.logLines.takeLast(200)) { line ->
                Text(
                    line,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun ResultScreen(state: DumpUiState) {
    val ctx = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (state.dumpPath != null) {
            Text("Dump selesai", style = MaterialTheme.typography.titleMedium)
            Text(state.dumpPath!!, fontFamily = FontFamily.Monospace)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                            as android.content.ClipboardManager
                    cm.setPrimaryClip(
                        android.content.ClipData.newPlainText("dump path", state.dumpPath)
                    )
                    Toast.makeText(ctx, "Path dicopy", Toast.LENGTH_SHORT).show()
                }) {
                    Text("COPY PATH")
                }

                Button(onClick = {
                    try {
                        val file = File(state.dumpPath!!)
                        val uri = FileProvider.getUriForFile(
                            ctx,
                            "${ctx.packageName}.fileprovider",
                            file
                        )
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, "text/plain")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Tidak bisa buka: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }) {
                    Text("OPEN FILE")
                }

                Button(onClick = {
                    try {
                        val file = File(state.dumpPath!!)
                        val uri = FileProvider.getUriForFile(
                            ctx,
                            "${ctx.packageName}.fileprovider",
                            file
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(intent, "Share dump.cs"))
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Share gagal: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }) {
                    Text("SHARE")
                }
            }
        } else {
            Text("Belum ada hasil dump.")
            Text("Jalankan dump dari tab Config.")
        }

        if (state.error != null) {
            Text("Error: ${state.error}", color = MaterialTheme.colorScheme.error)
        }
    }
}
