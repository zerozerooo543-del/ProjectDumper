package com.il2cpp.runtimedumper.scanner

import android.util.Log
import java.io.File

data class ProcessInfo(
    val pid: Int,
    val uid: Int,
    val cmdline: String,
    val packageName: String,
    val isVirtual: Boolean,
    val libraryPaths: List<String>
)

object PidScanner {

    private const val TAG = "PidScanner"

    /**
     * Scan /proc for processes matching the given package name.
     * Also detects common virtual-app sandbox paths.
     */
    fun scan(packageName: String): List<ProcessInfo> {
        val results = mutableListOf<ProcessInfo>()
        if (packageName.isBlank()) return results

        val proc = File("/proc")
        val dirs = proc.listFiles() ?: return results

        for (dir in dirs) {
            if (!dir.isDirectory) continue
            val pid = dir.name.toIntOrNull() ?: continue

            try {
                val cmdlineFile = File(dir, "cmdline")
                if (!cmdlineFile.canRead()) continue
                val cmdline = cmdlineFile.readBytes()
                    .toString(Charsets.UTF_8)
                    .replace("\u0000", " ")
                    .trim()
                if (cmdline.isEmpty()) continue

                // Match package name in cmdline
                if (!cmdline.contains(packageName)) continue

                val uid = readUid(dir)
                val maps = readMaps(dir)
                val isVirtual = detectVirtual(maps, cmdline)
                val libs = extractLibraries(maps)

                results.add(
                    ProcessInfo(
                        pid = pid,
                        uid = uid,
                        cmdline = cmdline,
                        packageName = packageName,
                        isVirtual = isVirtual,
                        libraryPaths = libs
                    )
                )
            } catch (t: Throwable) {
                Log.w(TAG, "Skip pid $pid: ${t.message}")
            }
        }
        return results.sortedByDescending { it.pid }
    }

    private fun readUid(procDir: File): Int {
        return try {
            val status = File(procDir, "status").readText()
            val line = status.lineSequence().firstOrNull { it.startsWith("Uid:") } ?: return -1
            line.split("\\s+".toRegex()).getOrNull(1)?.toIntOrNull() ?: -1
        } catch (_: Throwable) {
            -1
        }
    }

    private fun readMaps(procDir: File): List<String> {
        return try {
            File(procDir, "maps").readLines()
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun detectVirtual(maps: List<String>, cmdline: String): Boolean {
        val virtualHints = listOf(
            "/data/data/com.lbe.parallel",
            "/data/data/com.parallel.space",
            "/data/data/com.excelliance.dualaid",
            "/data/data/info.dodax.virtualspace",
            "/data/data/com.vphone.launcher",
            "/data/user/0/com.lbe.parallel",
            "/virtual/",
            "parallel_space",
            "dualspace",
            "island",
            "shelter",
            "virtualxposed",
            "blackbox"
        )
        val joined = (maps.joinToString(" ") + " " + cmdline).lowercase()
        return virtualHints.any { joined.contains(it) }
    }

    private fun extractLibraries(maps: List<String>): List<String> {
        val libs = mutableSetOf<String>()
        for (line in maps) {
            val path = line.substringAfterLast(' ', "").trim()
            if (path.endsWith(".so") && path.contains('/')) {
                libs.add(path)
            }
        }
        return libs.toList()
    }

    /**
     * Convenience: find first matching process and return its PID, or -1.
     */
    fun findPid(packageName: String): Int {
        return scan(packageName).firstOrNull()?.pid ?: -1
    }
}
