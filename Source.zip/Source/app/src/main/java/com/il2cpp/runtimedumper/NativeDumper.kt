package com.il2cpp.runtimedumper

object NativeDumper {

    init {
        try {
            System.loadLibrary("il2cppdumper")
        } catch (e: UnsatisfiedLinkError) {
            // Library will be loaded inside the target process via injection / virtual space
            android.util.Log.w("NativeDumper", "Native lib not loaded in host: ${e.message}")
        }
    }

    interface DumpCallback {
        fun onProgress(current: Int, total: Int, status: String)
        fun onLog(line: String)
    }

    /**
     * Starts the in-process dump.
     * Must be called from inside the target game process (after System.loadLibrary).
     *
     * @param libName      e.g. "libil2cpp.so" or "liblogic.so"
     * @param metadataName informational only (e.g. "global-metadata.dat")
     * @param outputPath   absolute path where dump.cs will be written
     * @param callback     progress + log callbacks (can be null)
     * @return absolute path of dump.cs on success, or string starting with "ERROR:"
     */
    external fun startDump(
        libName: String,
        metadataName: String,
        outputPath: String,
        callback: DumpCallback?
    ): String

    external fun stopDump()

    external fun isRunning(): Boolean
}
